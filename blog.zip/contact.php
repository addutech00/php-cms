<?php 
 include "includes/header.php";
 ?>
 <?php 
    if(isset($_POST['submit'])){
        $to = "gracelordgaming@gmail.com";
        $subject = $_POST['subject'];
        $message = $_POST['message'];
        $email = "From: " .$_POST['email'];

        mail($to, $subject, $message, $email);
    }
 ?>
     <div id="page-wrapper">
        <div class="container-fluid">
           
           
            <form action="" method="POST" enctype="multipart/form-data">
                <div class="form-group">
                    <label for="title">Email</label>
                    <input type="email" value="" name="email" class="form-control">
                </div>
                <div class="form-group">
                    <label for="title">Subject</label>
                    <input type="text" value="" name="subject" class="form-control">
                </div>
                <div class="form-group">
                    <label for="title">Message</label>
                    <textarea class="form-control" name="message" id="" cols="30" rows="10" placeholder="Message"></textarea>
                </div>

                <button name="submit" class="btn btn-primary">Submit</button>
            </form>
        </div>
    </div>
</div>
