<?php include "includes/header.php"; ?>
<?php include "includes/category-post-content.php"; ?>
<?php include "includes/sidebar.php"; ?>
<?php include "includes/footer.php";
      