
<?php
  include "includes/header.php";
  include "includes/sidebar.php";
 
    $source = '';
    if(isset($_GET['source'])){
      $source = $_GET['source'];
    }
    switch($source){
      case "add-user";
      include "includes/add-users.php";
      break;

      case "edit-user";
      include "includes/edit-user.php";
      break;

      default:
      include "includes/all-users.php";
      break;

    }

  include "includes/footer.php";
?>
