<?php
  include "includes/header.php";
  include "includes/sidebar.php";
  include "includes/body.php";
  include "includes/footer.php";
?>
