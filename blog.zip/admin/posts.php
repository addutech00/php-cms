
<?php
  include "includes/header.php";
  include "includes/sidebar.php";
 
    $source = '';
    if(isset($_GET['source'])){
      $source = $_GET['source'];
    }
    switch($source){
      case "add-post";
      include "includes/add-post.php";
      break;

      case "edit-post";
      include "includes/edit-post.php";
      break;

      default:
      include "includes/all-post.php";
      break;

    }

  include "includes/footer.php";
?>
