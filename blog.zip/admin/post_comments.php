<?php
  include "includes/header.php";
  include "includes/sidebar.php";
?>
<?php $post_id = $_GET['comment_id'] ?>

<div id="page-wrapper">
    <div class="container-fluid">
        <!-- Page Heading -->
        <div class="row">
            <div class="col-lg-12">
            <h1 class="page-header">Welcome To Admin Panel<small><?php echo $_SESSION['user_firstname']; ?> </small></h1>
            </div>
        </div>
        <form action="" method="POST">
        <div id="bulkOption" class="col-md-4">
            <select name="bulk_option" id="" class="form-control">
                <option value="">Select</option>
                <option value="Publish">Publish</option>
                <option value="Draft">Draft</option>
                <option value="Clone">Clone</option>
                <option value="Delete">Delete</option>
            </select>
        </div>
        <button class="btn btn-success">Apply</button>
        <a href="posts.php?source=add-post" class="btn btn-primary">Add New Post</a>
        <br><br>
        <table class="table">
            <tr>
                <th><input type="checkbox" name="bulkCheckBox" id="selectAllCheckBox"></th>
                <th>Id</th>
                <th>Post Title</th>
                <th>Comment</th>
                <th>Author</th>
                <th>Email</th>
                <th>Status</th>
                <th>Date</th>
                <th>Approve</th>
                <th>UnApprove</th>
                <th>Delete</th>
            </tr>
            <?php 
                $id = '';
                $showPostQuery = "SELECT * FROM comments WHERE comment_post_id = $post_id ORDER BY comment_id DESC";
                $exeShowPostQuery = mysqli_query($con, $showPostQuery);
                while($row = mysqli_fetch_assoc($exeShowPostQuery)){
                    $comment_id = $row['comment_id'];
                    $comment_post_id = $row['comment_post_id'];
                    $comment_author = $row['comment_author'];
                    $comment_email = $row['comment_email'];
                    $comment_content = $row['comment_content'];
                    $comment_status = $row['comment_status'];
                    $comment_date = $row['comment_date'];
                    $id++;
            ?>
            <tr>
                <td><input type="checkbox" class="checkBox" name="checkBoxArray[]" value="<?php echo $post_id; ?>" id=""></td>
                <td><?php echo $id; ?></td>
                <?php
                 $postTitleQuery = "SELECT post_title FROM posts WHERE post_id = $comment_post_id";
                 $exePostTitleQuery = mysqli_query($con, $postTitleQuery);
                 $row= mysqli_fetch_assoc($exePostTitleQuery);
                 $postTitle = $row['post_title'];
                 ?>
                <td><?php echo $postTitle; ?></td>
                <td><?php echo $comment_content; ?></td>
                <td><?php echo $comment_author; ?></td>
                <td><?php echo $comment_email; ?></td>
                <td><?php echo $comment_status; ?></td>
                <td><?php echo $comment_date; ?></td>
                <td><a href="post_comments.php?approve=<?php echo $post_id;?>&comment_id=<?php echo $post_id;?>">Approve</a></td>
                <td><a href="post_comments.php?unapprove=<?php echo $post_id;?>&comment_id=<?php echo $post_id;?>">UnApprove</a></td>
                <td><a onclick="javascript: return confirm('Are you sure to delete the selected post?');" href="post_comments.php?delete=<?php echo $post_id;?>&comment_id=<?php echo $post_id;?>">Delete</a></td>
            </tr>
                <?php } ?>
        </table>
        </form>
        <?php 
if(isset($_GET['delete'])){
    $delete = $_GET['delete'];
    $deleteQuery = "DELETE FROM comments WHERE comment_id = $comment_id";
    $exeDeleteQuery = mysqli_query($con, $deleteQuery);
    if($exeDeleteQuery){
        header('Location: post_comments.php?comment_id='.$post_id);
    }
}
?>
<?php 
    if(isset($_GET['approve'])){
        $approve = $_GET['approve'];

        $approveQuery = "UPDATE comments SET comment_status = 'published' WHERE comment_id = $comment_id";
        $exeApproveQUery = mysqli_query($con, $approveQuery);
        if($exeApproveQUery){
            header('Location: post_comments.php?comment_id='.$post_id);
        }
    }

    if(isset($_GET['unapprove'])){
        $unapprove = $_GET['unapprove'];

        $unapproveQuery = "UPDATE comments SET comment_status = 'unpublished' WHERE comment_id = $comment_id";
        $exeunApproveQUery = mysqli_query($con, $unapproveQuery);
        if($exeunApproveQUery){
            header('Location: post_comments.php?comment_id='.$post_id);
        }
    }
?>
        <!-- /.row -->
    </div>
<!-- /.container-fluid -->
</div>
<!-- /#page-wrapper -->
</div>
<!-- /#wrapper -->
<?php  include "includes/footer.php";
?>
