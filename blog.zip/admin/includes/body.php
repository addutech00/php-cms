<?php 
    adminIndexBodyPageCount('posts');
     // refactored code in functions.php
    
    // $postCountQuery = "SELECT * FROM posts";
    // $exePostCountQuery = mysqli_query($con, $postCountQuery);
    // $totalPost = mysqli_num_rows($exePostCountQuery);
?>
<?php 
    $totalActivePost = adminIndexBodyPageCounters('posts', 'post_status', 'publish');
// $activePostCountQuery = "SELECT * FROM posts WHERE post_status = 'publish'";
// $exeActivePostCountQuery = mysqli_query($con, $activePostCountQuery);
// $totalActivePost = mysqli_num_rows($exeActivePostCountQuery);
?>
<?php 
    $totalDraftPost = adminIndexBodyPageCounters('posts', 'post_status', 'draft');
// $draftPostCountQuery = "SELECT * FROM posts WHERE post_status = 'draft'";
// $exeDraftPostCountQuery = mysqli_query($con, $draftPostCountQuery);
// $totalDraftPost = mysqli_num_rows($exeDraftPostCountQuery);
?>
<?php 
    $totalComments = adminIndexBodyPageCount('comments');
// $commentCountQuery = "SELECT * FROM comments";
// $execommentCountQuery = mysqli_query($con, $commentCountQuery);
// $totalComments = mysqli_num_rows($execommentCountQuery);
?>
<?php 
    $totalUnapprovedComments = adminIndexBodyPageCounters('comments', 'comment_status', 'unpublished');
// $unapprovedCommentCountQuery = "SELECT * FROM comments WHERE comment_status ='unpublished'";
// $exeUnapprovedCommentCountQuery = mysqli_query($con, $unapprovedCommentCountQuery);
// $totalUnapprovedComments = mysqli_num_rows($exeUnapprovedCommentCountQuery);
?>
<?php 
    $totalUsers = adminIndexBodyPageCount('users');
// $usersCountQuery = "SELECT * FROM users";
// $exeusersCountQuery = mysqli_query($con, $usersCountQuery);
// $totalUsers = mysqli_num_rows($exeusersCountQuery);
?>
<?php 
$subsCountQuery = "SELECT * FROM users WHERE user_role !='admin'";
$exeSubsCountQuery = mysqli_query($con, $subsCountQuery);
$totalSubs = mysqli_num_rows($exeSubsCountQuery);
?>
<?php 
// We can use same funtionality as abouve we used but left for future remember and referneces

$categoryCountQuery = "SELECT * FROM categories";
$execategoryCountQuery = mysqli_query($con, $categoryCountQuery);
$totalCategories = mysqli_num_rows($execategoryCountQuery);
?>

<div id="page-wrapper">
    <div class="container-fluid">
        <!-- Page Heading -->
        <div class="row">
            <div class="col-lg-12">
                <h1 class="page-header">
                    Welcome <span class="usersonline"></span>
                    <small><?php echo $_SESSION['user_firstname']; ?> </small>
                </h1>
            </div>
        </div>
        <!-- /.row -->


<div class="row">
    <div class="col-lg-3 col-md-6">
        <div class="panel panel-primary">
            <div class="panel-heading">
                <div class="row">
                    <div class="col-xs-3">
                        <i class="fa fa-file-text fa-5x"></i>
                    </div>
                    <div class="col-xs-9 text-right">
                  <div class='huge'><?php echo $totalPost = adminIndexBodyPageCount('posts'); ?></div> <!-- refactored code in functions.php -->
                        <div>Posts</div>
                    </div>
                </div>
            </div>
            <a href="posts.php">
                <div class="panel-footer">
                    <span class="pull-left">View Details</span>
                    <span class="pull-right"><i class="fa fa-arrow-circle-right"></i></span>
                    <div class="clearfix"></div>
                </div>
            </a>
        </div>
    </div>
    <div class="col-lg-3 col-md-6">
        <div class="panel panel-green">
            <div class="panel-heading">
                <div class="row">
                    <div class="col-xs-3">
                        <i class="fa fa-comments fa-5x"></i>
                    </div>
                    <div class="col-xs-9 text-right">
                     <div class='huge'><?php echo $totalComments; ?></div>
                      <div>Comments</div>
                    </div>
                </div>
            </div>
            <a href="comments.php">
                <div class="panel-footer">
                    <span class="pull-left">View Details</span>
                    <span class="pull-right"><i class="fa fa-arrow-circle-right"></i></span>
                    <div class="clearfix"></div>
                </div>
            </a>
        </div>
    </div>
    <div class="col-lg-3 col-md-6">
        <div class="panel panel-yellow">
            <div class="panel-heading">
                <div class="row">
                    <div class="col-xs-3">
                        <i class="fa fa-user fa-5x"></i>
                    </div>
                    <div class="col-xs-9 text-right">
                    <div class='huge'><?php echo $totalUsers; ?></div>
                        <div> Users</div>
                    </div>
                </div>
            </div>
            <a href="users.php">
                <div class="panel-footer">
                    <span class="pull-left">View Details</span>
                    <span class="pull-right"><i class="fa fa-arrow-circle-right"></i></span>
                    <div class="clearfix"></div>
                </div>
            </a>
        </div>
    </div>
    <div class="col-lg-3 col-md-6">
        <div class="panel panel-red">
            <div class="panel-heading">
                <div class="row">
                    <div class="col-xs-3">
                        <i class="fa fa-list fa-5x"></i>
                    </div>
                    <div class="col-xs-9 text-right">
                        <div class='huge'><?php echo $totalCategories; ?></div>
                         <div>Categories</div>
                    </div>
                </div>
            </div>
            <a href="categories.php">
                <div class="panel-footer">
                    <span class="pull-left">View Details</span>
                    <span class="pull-right"><i class="fa fa-arrow-circle-right"></i></span>
                    <div class="clearfix"></div>
                </div>
            </a>
        </div>
    </div>
</div>
                <!-- /.row -->
<!-- Google Charts -->
<script type="text/javascript">
      google.charts.load('current', {'packages':['bar']});
      google.charts.setOnLoadCallback(drawStuff);

      function drawStuff() {
        var data = new google.visualization.arrayToDataTable([
          ['Opening Move', 'Total'],
          <?php
          $elementText = ['All Posts', 'Active Posts', 'Draft Posts', 'Comments', 'Unapproved Comments', 'Users', 'Subscribers','Categories'];
          $elementCount = [$totalPost, $totalActivePost, $totalDraftPost, $totalComments, $totalUnapprovedComments, $totalUsers, $totalSubs, $totalCategories];

          for($i=0; $i<8; $i++){
              echo "['{$elementText[$i]}'" . "," . "{$elementCount[$i]}],";
          }
          ?>
        ]);

        var options = {
          title: '',
          width: 900,
          legend: { position: 'none' },
          chart: { title: '',
                   subtitle: '' },
          bars: 'vertical', // Required for Material Bar Charts.
          axes: {
            x: {
              0: { side: 'top', label: 'Total'} // Top x-axis.
            }
          },
          bar: { groupWidth: "100%" }
        };

        var chart = new google.charts.Bar(document.getElementById('top_x_div'));
        chart.draw(data, options);
      };
    </script>   
<!-- /Google Charts -->
<div id="top_x_div" style="width: 900px; height: 500px;"></div>
  
    </div>
<!-- /.container-fluid -->
</div>
<!-- /#page-wrapper -->
</div>
<!-- /#wrapper -->