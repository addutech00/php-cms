

<div id="page-wrapper">
    <div class="container-fluid">
        <!-- Page Heading -->
        <div class="row">
            <div class="col-lg-12">
            <h1 class="page-header">Welcome To Admin Panel<small><?php echo $_SESSION['user_firstname']; ?> </small></h1>
            </div>
        </div>
        <div class="row">
            <div class="col-md-6">
            <?php addCategory(); ?>
                    <form action="" method="POST">
                        <div class="form-group">
                            <label for="add_category">Add Category</label>
                            <input type="text" name="cat_name" placeholder="Add Category" class="form-control">
                        </div>
                        <button class="btn btn-primary" name="add_category">Add Category</button><hr>
                    <?php 
                        if(isset($_GET['edit'])){
                            $id = $_GET['edit'];
                            $editQuery = "SELECT * FROM categories WHERE cat_id = $id";
                            $exeEditQuery = mysqli_query($con, $editQuery);
                            while($row = mysqli_fetch_assoc($exeEditQuery)){
                                $cat_id = $row['cat_id'];
                                $cat_name = $row['cat_name'];
                            }
                    ?>
                        <div class="form-group">
                            <label for="edit_category">Edit Category</label>
                            <input type="text" name="edit_cat" value="<?php echo $cat_name;?>" placeholder="Edit Category" class="form-control">
                        </div>
                        <button class="btn btn-primary" name="edit_category">Edit Category</button><hr>
                        <?php } ?>
                        
                        <?php 
                        if(isset($_POST['edit_category'])){
                            $cat_name = $_POST['edit_cat'];
                            $updateQuery = "UPDATE categories SET cat_name = '$cat_name' WHERE cat_id = $id";
                            $exeUpdateQuery = mysqli_query($con, $updateQuery);
                            if($exeUpdateQuery){
                                $_SESSION['message'] = "<div class='alert alert-success alert-dismissible'>
                                    <button type='button' class='close' data-dismiss='alert'>&times;</button>
                                    <strong>Added!</strong> Category Updated Successfully.
                                </div>";
                                header('Location: categories.php');
                            }
                        }
                    ?>
                    <?php deleteCategory(); ?>
                    </form>
            </div>
            <div class="col-md-6">
                <h3>Categories</h3>
                <table class="table">
                    <tr>
                        <th>Id</th>
                        <th>Name</th>
                        <th>Edit</th>
                        <th>Delete</th>
                    </tr>
                    <?php 
                        $id = '';
                        $showCatQuery = "SELECT * FROM categories";
                        $exeShowCatQuery = mysqli_query($con, $showCatQuery);
                        while($row = mysqli_fetch_assoc($exeShowCatQuery)){
                            $cat_id = $row['cat_id'];
                            $cat_name = $row['cat_name'];
                            $id++;
                    ?>
                    <tr>
                        <td><?php echo $id;?></td>
                        <td><?php echo $cat_name;?></td>
                        <td><a href="categories.php?edit=<?php echo $cat_id;?>">Edit</td>
                        <td><a href="categories.php?delete=<?php echo $cat_id;?>">Delete</td>
                    </tr>
                    <?php } ?>
                </table>
            </div>
        </div>
        <!-- /.row -->
    </div>
<!-- /.container-fluid -->
</div>
<!-- /#page-wrapper -->
</div>
<!-- /#wrapper -->