<?php 
    if(isset($_POST['add_post'])){
        $post_title = $_POST['post_title'];  // Check functions.php
        $post_cat_id = $_POST['post_cat_id'];
        $post_author = $_POST['post_author'];
        $post_status = $_POST['post_status'];
        $post_image = $_FILES['post_image']['name'];
        $post_image_temp = $_FILES['post_image']['tmp_name'];
        $post_tags = $_POST['post_tags'];
        $post_content = $_POST['post_content'];
        $post_date = date('d-m-y');

        move_uploaded_file($post_image_temp, "./images/$post_image");

        $addPostQuery = "INSERT INTO posts(post_title, post_cat_id, post_author, post_status, post_image, post_tags, post_content, post_date) VALUES('$post_title','$post_cat_id','$post_author','$post_status','$post_image','$post_tags','$post_content', now())";

        $exeAddPostQuery = mysqli_query($con, $addPostQuery);
        if($exeAddPostQuery){
            $_SESSION['message'] = "<div class='alert alert-success alert-dismissible'>
            <button type='button' class='close' data-dismiss='alert'>&times;</button>
            <strong>Added!</strong> Post Added Successfully.
          </div>";
            header('Location: posts.php');
        }else{
            die("An Error Occured". mysqli_error($con));
    }
    }
?>

<div id="page-wrapper">
    <div class="container-fluid">
        <!-- Page Heading -->
        <div class="row">
            <div class="col-lg-12">
                <h1 class="page-header">Welcome To Admin Panel<small><?php echo $_SESSION['user_firstname']; ?> </small></h1>
            </div>
        </div>
        <form action="" method="POST" enctype="multipart/form-data">
            <div class="form-group">
                <label for="title">Title</label>
                <input type="text" name="post_title" class="form-control">
            </div>
            <div class="form-group">
                <label for="title">Post Category Id</label>
                <select name="post_cat_id" id="" class="form-control">
                    <?php 
                        $selCatQuery = "SELECT * FROM categories";
                        $exeSelCatQuery = mysqli_query($con, $selCatQuery);
                        while($row = mysqli_fetch_assoc($exeSelCatQuery)){
                            $cat_id = $row['cat_id'];
                            $cat_name
                             = $row['cat_name'];
                            ?>
                            <option value="<?php echo $cat_id;?>"><?php echo $cat_name; ?></option>
                            <?php } ?>
                </select>
            </div>
            <div class="form-group">
                <label for="title">Author</label>
                <input type="text" name="post_author" class="form-control">
            </div>
            <div class="form-group">
                <label for="title">Status</label>
                <select name="post_status" id="" class="form-control">
                    <option value="Draft">Draft</option>
                    <option value="Publish">Publish</option>
                </select>
            </div>
            <div class="form-group">
                <label for="title">Image</label>
                <input type="file" name="post_image" class="form-control">
            </div>
            <div class="form-group">
                <label for="title">Tags</label>
                <input type="text" name="post_tags" class="form-control">
            </div>
            <div class="form-group">
                <label for="content">Content</label>
                <textarea name="post_content" id="editor" cols="30" rows="5" class="form-control"></textarea>
            </div>
            <button name="add_post" class="btn btn-primary btn-block">Add Post</button>
        </form>
        <!-- /.row -->
    </div>
<!-- /.container-fluid -->
</div>
<!-- /#page-wrapper -->
</div>
<!-- /#wrapper -->