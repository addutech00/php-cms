<?php
    $con = mysqli_connect('localhost', 'root', '', 'blog_cms');
?>