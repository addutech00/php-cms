<?php 
    if(isset($_GET['approve'])){
        if(isset($_SESSION['user_role'])){
            if(isset($_SESSION['user_role']) == 'Admin'){
        $comment_id = $_GET['approve'];

        $approveQuery = "UPDATE comments SET comment_status = 'published' WHERE comment_id = $comment_id";
        $exeApproveQUery = mysqli_query($con, $approveQuery);
        if($exeApproveQUery){
            header('Location: comments.php');
                }
            }
        }
    }

    if(isset($_GET['unapprove'])){
        if(isset($_SESSION['user_role'])){
            if(isset($_SESSION['user_role']) == 'Admin'){
        $comment_id = $_GET['unapprove'];

        $unapproveQuery = "UPDATE comments SET comment_status = 'unpublished' WHERE comment_id = $comment_id";
        $exeunApproveQUery = mysqli_query($con, $unapproveQuery);
        if($exeunApproveQUery){
            header('Location: comments.php');
            }
        }
    }
}
?>
<?php  deleteComment(); ?>


<div id="page-wrapper">
    <div class="container-fluid">
        <!-- Page Heading -->
        <div class="row">
            <div class="col-lg-12">
            <h1 class="page-header">Welcome To Admin Panel<small><?php echo $_SESSION['user_firstname']; ?> </small></h1>
            </div>
        </div>
        <table class="table">
            <tr>
                <th>Id</th>
                <th>Author</th>
                <th>Email</th>
                <th>Content</th>
                <th>Post Title</th>
                <th>Status</th>
                <th>Date</th>
                <th>Approve</th>
                <th>UnApprove</th>
                <th>Delete</th>
            </tr>
            <?php 
                $id = '';
                $showCommentsQuery = "SELECT * FROM comments";
                $exeShowCommentsQuery = mysqli_query($con, $showCommentsQuery);
                while($row = mysqli_fetch_assoc($exeShowCommentsQuery)){
                    $comment_id = $row['comment_id'];
                    $comment_author = $row['comment_author'];
                    $comment_email = $row['comment_email'];
                    $comment_content = $row['comment_content'];
                    $comment_post_id = $row['comment_post_id'];
                    $comment_status = $row['comment_status'];
                    $comment_date = $row['comment_date'];
                    $id++;
            ?>
            <tr>
                <td><?php echo $id; ?></td>
                <td><?php echo $comment_author; ?></td>
                <td><?php echo $comment_email; ?></td>
                <td><?php echo $comment_content; ?></td>
                <?php
                    $postTitleQuery = "SELECT * FROM posts WHERE post_id = $comment_post_id";
                    $exePostTitleQuery = mysqli_query($con, $postTitleQuery);
                    while($rows = mysqli_fetch_assoc($exePostTitleQuery)){
                        $post_title = $rows['post_title'];
                    }
                ?>
                <td><?php echo $post_title; ?></td>
                <td><?php echo $comment_status; ?></td>
                <td><?php echo $comment_date; ?></td>
                <td><a href="comments.php?approve=<?php echo $comment_id; ?>">Approve</a></td>
                <td><a href="comments.php?unapprove=<?php echo $comment_id; ?>">UnApprove</a></td>
                <td><a onclick="javascript: return confirm('Are you sure to delete the selected comment ?');" href="comments.php?delete=<?php echo $comment_id; ?>">Delete</a></td>
            </tr>
                <?php } ?>
        </table>
        <!-- /.row -->
    </div>
<!-- /.container-fluid -->
</div>
<!-- /#page-wrapper -->
</div>
<!-- /#wrapper -->