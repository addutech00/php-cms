<?php 
    include "connection.php";

    // This function is made to use for preventing mysqli injection
    // This function is saving us to write mysql_real_escape_string again and again and just escape($_POST['variable']) is all to do now.
    // Check add-post.php
    function escape($string){
        global $con;
        return mysqli_real_escape_string($con, trim($string));
    }



    function users_online() {
        global $con;
        if(isset($_GET['online'])){
            session_start();
                
            $time = time(); // Built in function
            $session = session_id(); // Built in function
            $time_in_seconds = 30;
            $time_out = $time - $time_in_seconds;
        
            $userOnlineQuery = "SELECT * FROM user_online WHERE session = '$session'";
            $exeUserOnlineQuery = mysqli_query($con, $userOnlineQuery);
            $count = mysqli_num_rows($exeUserOnlineQuery);
        
            if($count == NULL){
                mysqli_query($con, "INSERT INTO user_online(session, time) VALUES('$session', '$time')");
            }else{
                mysqli_query($con, "UPDATE user_online SET time = '$time' WHERE session = '$session'");
            }
            $onlineUsers = mysqli_query($con, "SELECT * FROM user_online WHERE time > '$time_out'");
            echo $countOnlineUsers = mysqli_num_rows($onlineUsers);
           
        }
    }
    users_online();
    
    function addCategory(){
        global $con;
        if(isset($_POST['add_category'])){
            $cat_name = $_POST['cat_name'];
            if($cat_name == "" || empty($cat_name)){
                echo "This Field Can't Be Empty";
            }else{
                $addCatQuery = "INSERT INTO categories (cat_name) VALUES('$cat_name')";
                $exeAddCatQuery = mysqli_query($con, $addCatQuery);
                header('Location: categories.php');
            }
        }
    }

    function deleteCategory(){
        global $con;
        if(isset($_GET['delete'])){
            $id = $_GET['delete'];
            $deleteQuery = "DELETE FROM categories WHERE cat_id = $id";
            $exeDeleteQuery = mysqli_query($con, $deleteQuery);
            if($exeDeleteQuery){
                header('Location: categories.php');
            }
        }
    }

    function deletePost(){
        global $con;
        if(isset($_GET['delete'])){
            $id = $_GET['delete'];
            $deleteQuery = "DELETE FROM posts WHERE post_id = $id";
            $exeDeleteQuery = mysqli_query($con, $deleteQuery);
            if($exeDeleteQuery){
                header('Location: posts.php');
            }
        }
    }
    
    function deleteComment(){
        global $con;
        if(isset($_GET['delete'])){
            $id = $_GET['delete'];
            $deleteQuery = "DELETE FROM comments WHERE comment_id = $id ";
            $exeDeleteQuery = mysqli_query($con, $deleteQuery);
            if($exeDeleteQuery){
                header('Location: comments.php');
            }
        }
    }

    function deleteUser(){
        global $con;
        if(isset($_GET['delete'])){
            $id = $_GET['delete'];
            $deleteQuery = "DELETE FROM users WHERE user_id = $id ";
            $exeDeleteQuery = mysqli_query($con, $deleteQuery);
            if($exeDeleteQuery){
                $_SESSION['message'] = "<div class='alert alert-danger'>
                <strong>Deleted!</strong> User Deleted Successfully.
              </div>";
                header('Location: users.php');
            }
        }
    }

    
    
    // global $con;
        // $time = time(); // Built in function
        // $session = session_id(); // Built in function
        // $time_in_seconds = 30;
        // $time_out = $time - $time_in_seconds;
    
        // $userOnlineQuery = "SELECT * FROM user_online WHERE session = '$session'";
        // $exeUserOnlineQuery = mysqli_query($con, $userOnlineQuery);
        // $count = mysqli_num_rows($exeUserOnlineQuery);
    
        // if($count == NULL){
        //     $insertNewSessionToDB = "INSERT INTO user_online(session, time) VALUES('$session', '$time')";
        //     $exeInsertNewSessionToDB = mysqli_query($con, $insertNewSessionToDB);
        // }else{
        //     $updateExistingSession = "UPDATE user_online SET time = $time WHERE session = '$session'";
        //     $exeUpdateExistingSession = mysqli_query($con, $updateExistingSession);
        // }
        // $onlineUsers = "SELECT * FROM user_online WHERE time > '$time_out'";
        // $exeOnlineUsers = mysqli_query($con, $onlineUsers);
        // $countOnlineUsers = mysqli_num_rows($exeOnlineUsers);
        // echo $countOnlineUsers;
?>

<?php 
    function adminIndexBodyPageCount($tableName){ // refactored code for body.php in admin
    global $con;
    
    $postCountQuery = "SELECT * FROM ". $tableName;
    $exePostCountQuery = mysqli_query($con, $postCountQuery);
    return $totalPost = mysqli_num_rows($exePostCountQuery);
}
?>

<?php 
    function adminIndexBodyPageCounters($tableName, $columnName, $status){
    global $con;

    $activePostCountQuery = "SELECT * FROM $tableName WHERE $columnName = '$status'";
    $exeActivePostCountQuery = mysqli_query($con, $activePostCountQuery);
    return $totalActivePost = mysqli_num_rows($exeActivePostCountQuery);
}
?>
<?php 
    function userExists($username){
        global $con;

        $query = "SELECT username FROM users WHERE username = '$username'";
        $exeQuery = mysqli_query($con, $query);
        if(mysqli_num_rows > 0){
            return true;
        }else{
            return false;
        }
    }

    function emailExists($user_email){
        global $con;

        $query = "SELECT user_email FROM users WHERE user_email = '$user_email'";
        $exeQuery = mysqli_query($con, $query);
        if(mysqli_num_rows($exeQuery) > 0){
            return true;
        }else{
            return false;
        }
    }
?>
<!--  -->