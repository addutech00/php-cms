<?php  deleteUser(); ?>

<div id="page-wrapper">
    <div class="container-fluid">
        <!-- Page Heading -->
        <div class="row">
            <div class="col-lg-12">
            <h1 class="page-header">Welcome To Admin Panel<small><?php echo $_SESSION['user_firstname']; ?> </small></h1>
            </div>
        </div>
         <?php 
            if(isset($_SESSION['message'])){
            echo $_SESSION['message'];
            } 
        ?>
        <table class="table">
            <tr>
                <th>Id</th>
                <th>UserName</th>
                <th>First Name</th>
                <th>Last Name</th>
                <th>Role</th>
                <th>Email</th>
                <th>Edit</th>
                <th>Delete</th>
            </tr>
            <?php 
                $id = '';
                $showUsersQuery = "SELECT * FROM users";
                $exeShowUsersQuery = mysqli_query($con, $showUsersQuery);
                while($row = mysqli_fetch_assoc($exeShowUsersQuery)){
                    $user_id = $row['user_id'];
                    $username = $row['username'];
                    $user_password = $row['user_password'];
                    $user_firstname = $row['user_firstname'];
                    $user_lastname = $row['user_lastname'];
                    $user_email = $row['user_email'];
                    $user_image = $row['user_image'];
                    $user_role = $row['user_role'];
                    $randSalt = $row['randSalt'];
                    $id++;
            ?>
            <tr>
                <td><?php echo $user_id; ?></td>
                <td><?php echo $username; ?></td>
                <td><?php echo $user_firstname; ?></td>
                <td><?php echo $user_lastname; ?></td>
                <td><?php echo $user_role; ?></td>
                <td><?php echo $user_email; ?></td>
                <td><a href="users.php?source=edit-user&id=<?php echo $user_id; ?>">Edit</a></td>
                <td><a onclick="javascript: return confirm('Are you sure to delete the selected user ?');" href="users.php?delete=<?php echo $user_id; ?>">Delete</a></td>
            </tr>
                <?php } ?>
        </table>
        <!-- /.row -->
    </div>
<!-- /.container-fluid -->
</div>
<!-- /#page-wrapper -->
</div>
<!-- /#wrapper -->