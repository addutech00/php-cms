<?php include "delete-modal.php"; ?>
<?php 
    if(isset($_POST['checkBoxArray'])){
        foreach($_POST['checkBoxArray'] as $checkBoxValue){
            $bulk_option = $_POST['bulk_option'];
            
            switch($bulk_option){
                case 'Publish':
                    $bulkPublishQuery = "UPDATE posts SET post_status = '$bulk_option' WHERE post_id = $checkBoxValue";
                    $exeBulkPublishQuery = mysqli_query($con, $bulkPublishQuery);
                    if($exeBulkPublishQuery){
                        header('posts.php');
                    }
                break;        

                case 'Draft':
                    $bulkDraftQuery = "UPDATE posts SET post_status = '$bulk_option' WHERE post_id = $checkBoxValue";
                    $exeBulkDraftQuery = mysqli_query($con, $bulkDraftQuery);
                    if($exeBulkDraftQuery){
                        header('posts.php');
                    }
                break;  
                case 'Delete':
                    $bulkDeleteQuery = "DELETE FROM posts WHERE post_id = $checkBoxValue";
                    $exeBulkDeleteQuery = mysqli_query($con, $bulkDeleteQuery);
                    if($exeBulkDeleteQuery){
                        header('posts.php');
                    }
                break;
                case 'Clone':
                    $bulkCloneQuery = "SELECT * FROM posts WHERE post_id = $checkBoxValue";
                    $exeBulkCloneQuery = mysqli_query($con, $bulkCloneQuery);
                    while($row = mysqli_fetch_assoc($exeBulkCloneQuery)){
                        $post_id = $row['post_id'];
                        $post_title = $row['post_title'];
                        $post_image = $row['post_image'];
                        $post_cat_id = $row['post_cat_id'];
                        $post_author = $row['post_author'];
                        $post_date = $row['post_date'];
                        $post_status = $row['post_status'];
                        $post_tags = $row['post_tags'];
                        $post_content = $row['post_content'];
                    }

                    $bulkCloneQuery = "INSERT INTO posts(post_title, post_cat_id, post_author, post_status, post_image, post_tags, post_content, post_date) VALUES('$post_title','$post_cat_id','$post_author','$post_status','$post_image','$post_tags','$post_content', now())";
                    $exeBulkCloneQuery = mysqli_query($con, $bulkCloneQuery);
                    if($exeBulkCloneQuery){
                        header('posts.php');
                    }
                break;
            }
        }
    }
?>

<?php  deletePost(); ?>
<div id="page-wrapper">
    <div class="container-fluid">
        <!-- Page Heading -->
        <div class="row">
            <div class="col-lg-12">
            <h1 class="page-header">Welcome To Admin Panel<small><?php echo $_SESSION['user_firstname']; ?> </small></h1>
            </div>
        </div>
        <form action="" method="POST">
        <div id="bulkOption" class="col-md-4">
            <select name="bulk_option" id="" class="form-control">
                <option value="">Select</option>
                <option value="Publish">Publish</option>
                <option value="Draft">Draft</option>
                <option value="Clone">Clone</option>
                <option value="Delete">Delete</option>
            </select>
        </div>
        <button class="btn btn-success">Apply</button>
        <a href="posts.php?source=add-post" class="btn btn-primary">Add New Post</a>
        <br><br>
        <table class="table">
            <tr>
                <th><input type="checkbox" name="bulkCheckBox" id="selectAllCheckBox"></th>
                <th>Id</th>
                <th>Title</th>
                <th>Image</th>
                <th>Category</th>
                <th>Author</th>
                <th>Status</th>
                <th>Date</th>
                <th>Comments</th>
                <th>View</th>
                <th>Edit</th>
                <th>Delete</th>
                <th>Views</th>
            </tr>
            <?php 
            $username =  $_SESSION['username'];
                $id = '';
                $showPostQuery = "SELECT * FROM posts ORDER BY post_id DESC";
                $exeShowPostQuery = mysqli_query($con, $showPostQuery);
                while($row = mysqli_fetch_assoc($exeShowPostQuery)){
                    $post_id = $row['post_id'];
                    $post_title = $row['post_title'];
                    $post_image = $row['post_image'];
                    $post_category_id = $row['post_cat_id'];
                    $post_author = $row['post_author'];
                    $post_date = $row['post_date'];
                    $post_status = $row['post_status'];
                    $postView = $row['post_views_count'];
                    $id++;
            ?>
            <tr>
                <td><input type="checkbox" class="checkBox" name="checkBoxArray[]" value="<?php echo $post_id; ?>" id=""></td>
                <td><?php echo $id; ?></td>
                <td><?php echo $post_title; ?></td>
                <td><img src="./images/<?php echo $post_image; ?>" width="100" height="50" alt=""></td>
                <?php 
                    
                    $showCatQuery = "SELECT * FROM categories  WHERE cat_id = $post_category_id";
                    $exeShowCatQuery = mysqli_query($con, $showCatQuery);
                    while($row = mysqli_fetch_assoc($exeShowCatQuery)){
                        $cat_id = $row['cat_id'];
                        $cat_name = $row['cat_name'];
                        // $id++;
                    }
                    ?>
                <td><?php echo $cat_name; ?></td>
                <td><?php echo $post_author; ?></td>
                <td><?php echo $post_status; ?></td>
                <td><?php echo $post_date; ?></td>
                <?php
                 $commentQuery = "SELECT * FROM comments WHERE comment_post_id = $post_id";
                 $exeCommentQuery = mysqli_query($con, $commentQuery);
                 $countComment = mysqli_num_rows($exeCommentQuery);
                 ?>
                <td><a href="post_comments.php?comment_id=<?php echo $post_id;?>"><?php echo $countComment; ?></a></td>
                <td><a target="_blank" href="../post.php?p_id=<?php echo $post_id; ?>">View</a></td>
                <td><a href="posts.php?source=edit-post&id=<?php echo $post_id; ?>">Edit</a></td>
                <!-- This is the one and simple way of doing alert and delete second way is modal which will be active -->
                <!-- <td><a onclick="javascript: return confirm('Are you sure to delete the selected post?');" href="posts.php?delete=<?php echo $post_id; ?>">Delete</a></td> -->
                    
                    <!-- Using modal popup box -->
                    <!-- We will add some jquery and javascript to create popup box and bootstrap modal -->
                <td><a rel="<?php echo $post_id; ?>" class="delete_link" href="javascript:void(0);">Delete</a></td>
                <td><?php echo $postView; ?></td>
            </tr>
                <?php } ?>
        </table>
        </form>
        <!-- /.row -->
    </div>
<!-- /.container-fluid -->
</div>
<!-- /#page-wrapper -->
</div>
<!-- /#wrapper -->