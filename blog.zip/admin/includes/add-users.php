<?php 
    if(isset($_POST['add_user'])){
        $username = mysqli_real_escape_string($con, $_POST['username']);
        $user_password = mysqli_real_escape_string($con, $_POST['user_password']);
        $user_firstname = mysqli_real_escape_string($con, $_POST['user_firstname']);
        $user_lastname = mysqli_real_escape_string($con, $_POST['user_lastname']);
        // $post_image = $_FILES['post_image']['name'];
        // $post_image_temp = $_FILES['post_image']['tmp_name'];
        $user_email = mysqli_real_escape_string($con, $_POST['user_email']);
        $user_role = mysqli_real_escape_string($con, $_POST['user_role']);
        // $post_date = date('d-m-y');
        $randSalt = "SELECT randSalt FROM users";
        $exeRandSalt = mysqli_query($con, $randSalt);
        while($row = mysqli_fetch_assoc($exeRandSalt)){
            $salt = $row['randSalt'];
        }
        $user_password = crypt($user_password, $salt);
        // move_uploaded_file($post_image_temp, "./images/$post_image");

        $addUsersQuery = "INSERT INTO users(username, user_password, user_firstname, user_lastname, user_email, user_role) VALUES('$username','$user_password','$user_firstname','$user_lastname','$user_email','$user_role')";

        $exeAddUsersQuery = mysqli_query($con, $addUsersQuery);
        if($exeAddUsersQuery){
          
            $_SESSION['message'] = "<div class='alert alert-success alert-dismissible'>
            <button type='button' class='close' data-dismiss='alert'>&times;</button>
            <strong>Added!</strong> User Added Successfully.
          </div>";
            header('Location: users.php');
           
        }
    }
?>
    <div id="page-wrapper">
        <div class="container-fluid">
            <!-- Page Heading -->
            <div class="row">
                <div class="col-lg-12">
                <h1 class="page-header">Welcome To Admin Panel<small><?php echo $_SESSION['user_firstname']; ?> </small></h1>
                </div>
            </div>
           
            <form action="" method="POST" enctype="multipart/form-data">
                
                <div class="form-group">
                    <label for="title">First Name</label>
                    <input type="text" value="" name="user_firstname" class="form-control">
                </div>
                <div class="form-group">
                    <label for="title">Last Name</label>
                    <input type="text" value="" name="user_lastname" class="form-control">
                </div>
                <div class="form-group">
                    <label for="title">Username</label>
                    <input type="text" value="" name="username" class="form-control">
                </div>
                <div class="form-group">
                    <label for="title">Password</label>
                    <input type="password" value="" name="user_password" class="form-control">
                </div>
                <div class="form-group">
                    <label for="title">User Role</label>
                    <select name="user_role" id="" class="form-control">
                        <option value="admin">Admin</option>
                        <option value="subscriber">Subscriber</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="title">Email</label>
                    <input type="email" value="" name="user_email" class="form-control">
                </div>
                <div class="form-group">
                    <label for="title">Edit</label>
                    <input type="file" value="" name="post_title" class="form-control">
                </div>

                <button name="add_user" class="btn btn-primary">Add User</button>
            </form>
        </div>
    </div>
</div>
