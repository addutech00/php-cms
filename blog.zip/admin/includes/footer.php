

    <!-- jQuery -->
    <script src="js/scripts.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="js/bootstrap.min.js"></script>
    <script>
       $(document).ready(function(){
        ClassicEditor
            .create( document.querySelector( '#editor' ) )
            .then( editor => {
                    console.log( editor );
            } )
            .catch( error => {
                    console.error( error );
            } );
       });
    </script>

    <script>
//     Select All Check Box Query

$(document).ready(function(){
        $('#selectAllCheckBox').click(function(event){
                if(this.checked){
                        $('.checkBox').each(function(){
                                this.checked = true;
                        });
                }else{
                        $('.checkBox').each(function(){
                                this.checked = false;
                        }); 
                }
        });
});
    </script>
    <script>
        var div_box = "<div id='load-screen'><div id='loading'></div>";
        $('body').prepend(div_box);
        $('#load-screen').delay(700).fadeOut(600, function(){
                $(this).remove();
        });
    </script>

    <!-- Ajax for online Users -->
 <script>
function loadUsersOnline() {
	$.get("includes/functions.php?online=result", function(data){
                $(".online").text(data);
                console.log('Here');
	});
} 
setInterval(function(){
	loadUsersOnline();
},500);
</script>

<script>
        $(document).ready(function(){
                $(".delete_link").on('click', function(){
                        var id = $(this).attr("rel");
                        var delete_url = "posts.php?delete="+ id +" ";
                        $(".delete_class_for_js").attr("href", delete_url);
                        $("#myModal").modal('show');
                });
        });
</script>
   
</body>

</html>
