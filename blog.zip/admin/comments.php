
<?php
  include "includes/header.php";
  include "includes/sidebar.php";
 
 $source = '';
 if(isset($_GET['source'])){
     $source = $_GET['source'];
 }
 switch($source){
     case 'edit-comment';
     include "includes/all-comments.php";
     break;

     default:
     include "includes/all-comments.php";
     break;
 }
  include "includes/footer.php";
?>
