 <!-- Blog Sidebar Widgets Column -->
 <div class="col-md-4">
<!-- Blog Search Well -->
<div class="well">
    <h4>Blog Search</h4>
    <div class="input-group">
        <input type="text" class="form-control">
        <span class="input-group-btn">
            <button class="btn btn-default" type="button">
                <span class="glyphicon glyphicon-search"></span>
        </button>
        </span>
    </div>
    <!-- /.input-group -->
</div>
<!-- Blog Categories Well -->
<div class="well">
    <h4>Blog Categories</h4>
    <div class="row">
        <div class="col-lg-12">
        <?php 
            $catQuery = "SELECT * FROM categories";
            $exeCatQuery = mysqli_query($con, $catQuery);
            while($row = mysqli_fetch_assoc($exeCatQuery)){
                $cat_id = $row['cat_id'];
                $cat_name = $row['cat_name'];
        ?>
            <ul class="list-unstyled">
                <li><a href="category.php?category=<?php echo $cat_id; ?>"><?php echo $cat_name; ?></a></li>
            <?php } ?>
            </ul>
        </div>
        <!-- /.col-lg-12 -->
    </div>
    <!-- /.row -->
</div>

<!-- Another shorthand php property -->

<?php if(isset($_SESSION['user_role'])): ?> <!-- Nice and Pretty Shorthand try -->

    <div class="well">
        <p>Logged In As <b><?php echo $_SESSION['user_firstname']; ?></b></p>
        <a class="btn btn-primary" href="./admin/includes/logout.php">Logout</a>
    </div>

<?php else: ?> <!-- Nice and Pretty Shorthand try -->

    <div class="well">
    <form action="includes/login.php" method="POST">
        <div class="form-group">
            <input type="text" placeholder="Username" name="username" class="form-control">
        </div>
        <div class="form-group">
            <input type="password" placeholder="Password" name="user_password" class="form-control">
        </div>
        <button class="btn btn-primary btn-block" name="login">Login</button>
    </form>
</div>

<?php endif; ?> <!-- End with semicolon just like jinja -->

<!-- Side Widget Well -->
<div class="well">
    <h4>Side Widget Well</h4>
    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Inventore, perspiciatis adipisci accusamus laudantium odit aliquam repellat tempore quos aspernatur vero.</p>
</div>

</div>