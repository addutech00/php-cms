
 <!-- Page Content -->
 <div class="container">
        <div class="row">
            <!-- Blog Entries Column -->
            <div class="col-md-8">
                <!-- <h1 class="page-header">Page Heading<small>Secondary Text</small></h1> -->
                <!-- First Blog Post -->
                <?php 
                    $postCountQuery = "SELECT * FROM posts WHERE post_status != 'Draft'";
                    $exePostCountQuery = mysqli_query($con, $postCountQuery);
                    $count = mysqli_num_rows($exePostCountQuery);
                    if($count<1){
                        echo "<h1 class='text-center'>NO POSTS</h1>";
                    }else{
                    $count = ceil($count / 2);

                    if(isset($_GET['page'])){ // Check if there is page query request
                        $page = $_GET['page']; // Assign the value to a variable
                    }else{
                        $page = ''; // If not found assign it with empty string so no error shows on the page.
                    }

                    if($page == "" || $page == 1){ // If empty page or page is equal to 1
                        $page_1 = 0; // Assign the value of limit to 0
                    }else{
                        $page_1 = ($page * 2) - 2; // Now the value of page multiplied by limit of the page - limit so that exact value comes.
                    } // eg. page = 1 i.e- (1 * 2) - 2 = 0
                    // (2 * 2) - 2 = 2 and so on 


                    $query = "SELECT * FROM posts WHERE post_status != 'Draft' ORDER BY post_id DESC LIMIT $page_1, 2";
                    $exeQuery = mysqli_query($con, $query);
                    while($row = mysqli_fetch_assoc($exeQuery)){
                        $post_id = $row['post_id'];
                        $post_cat_id = $row['post_cat_id'];
                        $post_title = $row['post_title'];
                        $post_author = $row['post_author'];
                        $post_user = $row['post_user'];
                        $post_date = $row['post_date'];
                        $post_image = $row['post_image'];
                        $post_content = $row['post_content'];
                        $post_tags = $row['post_tags'];
                ?>
                <h2><a href="post.php?p_id=<?php echo $post_id; ?>"><?php echo $post_title; ?></a></h2>
                <p class="lead">by <?php echo $post_author; ?></p>
                <p><span class="glyphicon glyphicon-time"></span> Posted on <?php echo $post_date; ?></p>
                <hr>
                <a href="post.php?p_id=<?php echo $post_id; ?>"><img class="img-responsive" height="100px" width="100%" src="./admin/images/<?php echo $post_image;?>" alt=""></a>
                <hr>
                <p><?php echo substr($post_content, 0, 50) . '...'; ?></p>
                <a class="btn btn-primary" href="post.php?p_id=<?php echo $post_id; ?>">Read More <span class="glyphicon glyphicon-chevron-right"></span></a>
                <hr>
                <?php } ?>
                <!-- Pager -->
                <ul class="pager">
                <?php 
                    for($i=1; $i<=$count; $i++){
                        if($i == $page){
                            ?>
                <li><a class="active" href="index.php?page=<?php echo $i; ?>"><?php echo $i; ?></a></li>
                <?php }else{ ?>
                   <li><a href="index.php?page=<?php echo $i; ?>"><?php echo $i; ?></a></li>
                    <?php } } } ?>
                </ul>
            </div>