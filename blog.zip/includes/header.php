<?php include "includes/connection.php" ?>
<?php session_start(); ?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <title>Blog Home - Start Bootstrap Template</title>
    <link href="/blog/css/bootstrap.min.css" rel="stylesheet">
    <link href="/blog/css/blog-home.css" rel="stylesheet">
    <link href="/blog/css/loader.css" rel="stylesheet">
    <link href="/blog/css/pagination-active.css" rel="stylesheet">

</head>
<body>
    <nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
        <div class="container">
            <!-- Brand and toggle get grouped for better mobile display -->
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="index.php">Start Bootstrap</a>
            </div>
            <!-- Collect the nav links, forms, and other content for toggling -->
            <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                <ul class="nav navbar-nav">
                    <li>
                        <a href="./admin">Admin</a>
                    </li>
                    <?php 
                        $navQuery = "SELECT * FROM categories";
                        $exeNavQuery = mysqli_query($con, $navQuery);
                        while($row = mysqli_fetch_assoc($exeNavQuery)){
                            $cat_id = $row['cat_id'];
                            $cat_name = $row['cat_name'];
                            $cat_class = '';
                            if(isset($_GET['category']) && $_GET['category'] == $cat_id){
                                $cat_class = 'active';
                            }
                        ?>
                    <li class="<?php echo $cat_class; ?>">
                        <a href="category.php?category=<?php echo $cat_id; ?>"><?php echo $row['cat_name']; ?></a>
                    </li>
                    <?php
                        }
                    ?>
                    <?php if(isset($_SESSION['user_role'])){
                        if(isset($_GET['p_id'])){
                            $id = $_GET['p_id'];
                            ?>
                        <li><a href='./admin/posts.php?source=edit-post&id=<?php echo $id; ?>'>Edit Post</a></li>
                    <?php
                        }
                    } ?>
                    
                </ul>
            </div>
            <!-- /.navbar-collapse -->
        </div>
        <!-- /.container -->
    </nav>