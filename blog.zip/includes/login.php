<?php include "connection.php"; ?>
<?php session_start(); ?>
<?php 
    // if(isset($_POST['login'])){
    //     $username = mysqli_real_escape_string($con, $_POST['username']);
    //     $user_password = mysqli_real_escape_string($con, $_POST['user_password']);

    //     $loginQuery = "SELECT * FROM users WHERE username = '$username'";
    //     $exeLoginQuery = mysqli_query($con, $loginQuery);
    //     if(!$exeLoginQuery){
    //         die('Query Failed' . mysqli_error($con));
    //     }
    //     while($row = mysqli_fetch_assoc($exeLoginQuery)){
    //         $showUserId = $row['user_id'];
    //         $showUsername = $row['username'];
    //         $showUserPassword = $row['user_password'];
    //         $showUserFirstName = $row['user_firstname'];
    //         $showUserLastName = $row['user_lastname'];
    //         $showUserRole = $row['user_role'];
    //     }
    //     if($username !== $showUsername && $user_password !== $showUserPassword){
    //         header('Location: ../');
    //     }elseif($username == $showUsername && $user_password == $showUserPassword){
    //         header('Location: ../admin');
    //     }else{
    //         header('Location: ../');
    //     }
    // }
?>
<?php 
    if(isset($_POST['login'])){
    $username = mysqli_real_escape_string($con, $_POST['username']);
    $user_password = mysqli_real_escape_string($con, $_POST['user_password']);
    
    $loginQuery = "SELECT * FROM users WHERE username = '$username'";
    $exeLoginQuery = mysqli_query($con, $loginQuery);
    if(!$exeLoginQuery){
        die('Query Failed' . mysqli_error($con));
    }
    while($row = mysqli_fetch_assoc($exeLoginQuery)){
        $showUserId = $row['user_id'];
            $showUsername = $row['username'];
            $showUserPassword = $row['user_password'];
            $showUserFirstName = $row['user_firstname'];
            $showUserLastName = $row['user_lastname'];
            $showUserRole = $row['user_role'];
    }
    $user_password = crypt($user_password, $showUserPassword);
    if($username === $showUsername && $user_password === $showUserPassword){
        $_SESSION['username'] = $showUsername;
        $_SESSION['user_firstname'] = $showUserFirstName;
        $_SESSION['user_lastname'] = $showUserLastName;
        $_SESSION['user_role'] = $showUserRole;
        $_SESSION['username'] = $showUsername;
        header('Location: ../admin/');
    }else{
        header('Location: ../');
    }
}
?>