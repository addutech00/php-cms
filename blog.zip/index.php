<?php 
 include "includes/header.php";
 include "includes/post-body.php";
 include "includes/sidebar.php";
 include "includes/footer.php";
?>

